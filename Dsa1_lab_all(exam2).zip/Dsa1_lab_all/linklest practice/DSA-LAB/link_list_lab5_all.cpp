#include<iostream>
using namespace std;

struct node
{
    int val;
    node *next;
};

node* head = NULL;

void insertBegin(int x)
{
    node* newItem = new node();
    newItem->val = x;
    newItem->next = head;
    head=newItem;
}

void insertLast(int x)
{
    node* newItem = new node();
    if(head==NULL)
    {
        newItem->val = x;
        newItem->next = NULL;
        head = newItem;
    }
    else
    {
        newItem->val = x;
        node* temp;
        temp = head;
        while(temp->next!=NULL)
        {
            temp = temp->next;
        }
        temp->next = newItem;
        newItem->next = NULL;
    }
}

void insertLast2(int x)
{
    if(head==NULL)
        insertBegin(x);
    else
    {
        node* newItem = new node();
        newItem->val = x;
        node* temp;
        temp = head;
        while(temp->next!=NULL)
        {
            temp = temp->next;
        }
        temp->next = newItem;
        newItem->next = NULL;
    }
}


void insertAfter(int x, int target)
{
    node *newItem = new node();
    newItem->val = x;
    node *temp;
    temp = head;
    while(temp->val!=target)
        temp = temp->next;
    newItem->next=temp->next;
    temp->next=newItem;
}

void deleteBegin()
{
    if(head==NULL)
        return;
    else
        head = head->next;
}

void deleteLast()
{
    if(head==NULL)
        return;
    node *temp = head;
    node *prev = NULL;
    while(temp->next!=NULL){
        prev = temp;
        temp = temp->next;
    }
    if(prev==NULL) head=NULL;
    else prev->next = NULL;
}


void display()
{
    node* temp = head;
    while(temp!=NULL)
    {
        cout<<temp->val<<"->";
        temp = temp->next;
    }
    cout<<endl;
}
void deleteTarget(int target){
    if(head==NULL){
        return;
    }
    node*temp=head;
    node*prev=NULL;
    while (temp->next!=NULL&& temp->val!=target){
        prev=temp;
        temp=temp->next;

    }
    node*temp1=prev;
    if(prev==NULL){
        return;
    }else{
   prev->next=temp->next;
    }
   

 }

 int leanth(){
    node *temp=head;
    int count=0;
while (temp!=NULL){
    temp=temp->next;
    count++;
}
return count;

 }
  void reverse(){
    node*temp=head;
    node*prev=NULL;
    node*after=NULL;
  while (temp!=NULL)
  {
    after=temp->next;
    temp->next=prev;
    prev=temp;
    temp=after;
  }
  head=prev;

  }
  int  mid(){
     node*temp=head;
    int l=leanth();
    int mid=(l/2);
    for(int i=0;i<mid;i++){
        temp=temp->next;
    }
    return temp->val;
  }
  int mid_slow_fast(){
    node*first=head;
    node*slow=head;
    
    while (first->next!=NULL&&first!=NULL)
    {
        first=first->next->next;
        slow=slow->next;
    }
    return slow->val;


  }
   void bubbolsort(){
    node*i;
     node*j;

    for(i=head;i->next!=NULL;i=i->next){
    for(j=head;j->next!=NULL;j=j->next){
        if(j->val<j->next->val){
           int  temp=j->val;
           j->val=j->next->val;
           j->next->val=temp;
        }
    }
}

}




int main()
{
    insertBegin(3);
    insertLast(4);
    insertLast(6);
    insertLast(7);
    insertLast(8);
     display();
  int l=leanth();
  cout<<"lenth="<<l<<endl;

 //  reverse();
   int m= mid();
   //second way to mid;
   int m1=mid_slow_fast();
   cout<<"mid="<<m<<endl;
    cout<<"mid2="<<m1<<endl;
     display();
    bubbolsort();

    display();
}
