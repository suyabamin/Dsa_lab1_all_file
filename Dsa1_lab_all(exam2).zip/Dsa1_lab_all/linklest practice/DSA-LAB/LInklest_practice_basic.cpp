#include<iostream>
using namespace std;
struct node{
node*next;
int value;

};
node* head=NULL;
//print
void print(){
  cout<<"your link lest is-----"<<endl;
node *temp=head;
while(temp!=NULL){
    cout<<temp->value<<"->";
    temp=temp->next;
}
cout<<" "<<endl;
}

void insertbegain(int x){
node*newItem=new node();
newItem->value=x;
newItem->next=head;
head=newItem;

}
void  insertlast(int x){
node*newItem=new node();

if(head==NULL){
  insertbegain(x);
}else{
    node*temp=head;
newItem->value=x;
while(temp->next!=NULL){
    temp=temp->next;
}
  temp->next=newItem;
  newItem->next=NULL;

}
}
void insertAfter(int n,int x){
node* newItem=new node();
if(head==NULL){
    insertbegain(x);
}else{
node*temp=head;
  while(temp!=NULL&&temp->value!=n){

        temp=temp->next;

}
newItem->value=x;
newItem->next=temp->next;
temp->next=newItem;
}

}
void deleteBegain(){
    if(head==NULL){
        return;
    }else{
   node*temp=head;
   head=head->next;
   delete(temp);
    }
}

void  deleteLast(){
  if(head==NULL){
    return;
  }
  node*temp=head;
  node*prev=NULL;
  while(temp->next!=NULL){
        prev=temp;
    temp=temp->next;
  }if(prev==NULL){
    head=NULL;
  }
  prev->next=NULL;
}

void insert_in_position(int n,int x){
  if(n==1){
    insertbegain(x);
  }
  node*newItem=new node();
  node*temp=head;
  for(int i=1;i<n-1;i++){
     temp=temp->next;
  }
  newItem->value=x;
   newItem->next=temp->next;
   temp->next=newItem;

}void delete_in_position(int n){
  if(n==1){
    deleteBegain();
  }
  
  node*temp=head;
  node*temp1;
  for(int i=1;i<n-1;i++){
     temp=temp->next;
  }
  temp1=temp->next;
  temp->next=temp->next->next;
delete(temp1);

}
void scarch(int n){
  node*temp=head;
  int index=1;
  while (temp!=NULL)
  {
    if(temp->value==n){
      cout<<"found "<<n<<"in "<<index<<"th position"<<endl;
    }
    temp=temp->next;
    index++;
  }
  

}

void reversePrint(){

  if(head==NULL){
    return;
  }

  node* current=head;
  node* prev=NULL;
  node* next=NULL;
  while (current!=NULL)
  {
      next=current->next;
      current->next=prev;
      prev=current;
      current=next;
    
  }
  head=prev;
  print();


 
}
/// @brief /////////
void count(){
node*temp=head;
int count=0;
while (temp!=NULL)
{
  count++;
  temp=temp->next;
}
cout<<"total node-"<<count<<endl;

}
void count(){
node*temp=head;
int count=0;
while (temp!=NULL)
{
  count++;
  temp=temp->next;
}
cout<<"total node-"<<count<<endl;

}


void manue(){
  cout<<"------------------enter any choice-----------------------"<<endl;
  cout<<"1)insert first"<<endl;
   cout<<"2)insert last"<<endl;
    cout<<"3)delete begain"<<endl;
     cout<<"4)delete last"<<endl;
      cout<<"5)insert n th---"<<endl;
      cout<<"6)print"<<endl;
       cout<<"7)insert in position";
      cout<<"8)delete in position value"<<endl;
      cout<<"9)scarch"<<endl;
        cout<<"10)reverse printn"<<endl;
        cout<<"11)counte node"<<endl;

       cout<<"0)Exit"<<endl;
}

int main(){

  while (1)
  {
  
  manue();
  int n;
  cout<<"enter any choice------";
  cin>>n;
  if(n==1){
    int k;
    cout<<"enter the value you want to insert----";
    cin>>k;
    insertbegain(k);
  }else if(n==2){
    int k;
    cout<<"enter the value you want to insert----";
    cin>>k;
    insertlast(k);
  }else if(n==3){
    
     deleteBegain();
  }else if(n==4){
    
     deleteLast();
  }

  else if(n==5){
    int k,l;
    cout<<"enter the value you want to after insert----";
    cin>>k;
    cout<<"enter the value you want to after insert----";
    cin>>l;
   insertAfter(k,l); 
  }else if(n==6){
     print();
     
  }else if(n==0){
   break;
     
  }else if(n==7){
    int k,l;
    cout<<"enter the n----";
    cin>>k;
    cout<<"enter the value you want to after insert----";
    cin>>l;
   insert_in_position(k,l);
  }else if(n==8){
    int k,l;
    cout<<"enter the n----";
    cin>>k;
    
   delete_in_position(k);
  }else if(n==9){
    int k;
    cout<<"enter the value----";
    cin>>k;
    
  scarch(k);
  }else if(n==10){
    reversePrint();
  }else if(n==11){
   count();
  }
  
  
  else{
    cout<<"invalid input  choice again";
  }

}

return 0;
}
