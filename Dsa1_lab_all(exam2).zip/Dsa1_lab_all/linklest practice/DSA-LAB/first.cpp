#include<iostream>
using namespace std;
int main(){
    string name;
   cout<<"enter any name--"<<endl;
    cin>>name;
    cout<<name<<endl;
    cout<<"enter your id num-";
    int id;
    cin>>id;
    cout<<id;
    return 0;
}