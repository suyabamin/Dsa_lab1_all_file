#include<iostream>
using namespace std;
int main(){
    cout<<"git puss";
}
