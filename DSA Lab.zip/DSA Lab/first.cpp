#include<iostream>
using namespace std;

int main(){
    int a=10;
cout<<"hello world"<<endl;
cout<<"age"<<a<<endl;
//input
int age;
cout<<"enter age=";
cin>>age;
cout<<"your age is"<<age;
return 0;
}
